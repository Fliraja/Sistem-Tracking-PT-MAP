<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-6 mt-6">
        <h2 class="text-2xl font-semibold mb-4">Form Absensi Mobil</h2>

        <form action="<?php echo e(route('attendances.store')); ?>" method="POST" enctype="multipart/form-data" id="attendanceForm">
            <?php echo csrf_field(); ?>

            <!-- Nomor Plat -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nomor Plat</label>
                <select name="mobil_id" class="w-full border-gray-300 rounded-lg mt-1">
                    <option value="">-- Pilih Mobil --</option>
                    <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mobil->id); ?>"><?php echo e($mobil->plat); ?> - <?php echo e($mobil->jenis); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Nama Pengemudi -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nama Pengemudi</label>
                <input type="text" name="nama" class="w-full border-gray-300 rounded-lg mt-1" required>
            </div>

            <!-- Tanggal dan Jam -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Tanggal & Jam Keberangkatan</label>
                <input type="datetime-local" name="tanggal_berangkat" class="w-full border-gray-300 rounded-lg mt-1" required>
            </div>

            <!-- Supplier -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Supplier</label>
                <input type="text" name="supplier" class="w-full border-gray-300 rounded-lg mt-1" required>
            </div>

            <!-- Ukuran -->
            <div class="grid grid-cols-3 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 font-medium">Panjang (m)</label>
                    <input type="number" step="0.01" name="panjang" id="panjang"
                        class="w-full border-gray-300 rounded-lg mt-1">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium">Lebar (m)</label>
                    <input type="number" step="0.01" name="lebar" id="lebar"
                        class="w-full border-gray-300 rounded-lg mt-1">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium">Tinggi (m)</label>
                    <input type="number" step="0.01" name="tinggi" id="tinggi"
                        class="w-full border-gray-300 rounded-lg mt-1">
                </div>
            </div>

            <!-- Volume otomatis -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Volume (m³)</label>
                <input type="number" step="0.01" name="volume" id="volume"
                    class="w-full border-gray-300 rounded-lg mt-1 bg-gray-100" readonly>
            </div>

            <!-- Nomor Plat -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Status</label>
                <select name="status" class="w-full border-gray-300 rounded-lg mt-1">
                    <option value="">-- Pilih Status --</option>
                    <option value="proses" selected>Proses</option>
                    <option value="perjalanan">Perjalanan</option>
                    <option value="selesai">Selesai</option>
                </select>
            </div>

            <!-- Foto Berangkat -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Foto Berangkat</label>
                <input type="file" name="foto_berangkat" accept="image/*"
                    class="w-full mt-1 border-gray-300 rounded-lg">
            </div>

            <!-- Foto Sampai -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Foto Sampai</label>
                <input type="file" name="foto_sampai" accept="image/*"
                    class="w-full mt-1 border-gray-300 rounded-lg">
            </div>

            <!-- Tombol Submit -->
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                    Simpan Data
                </button>
            </div>
        </form>
    </div>

    <script>
        // Hitung volume otomatis
        document.querySelectorAll('#panjang, #lebar, #tinggi').forEach(input => {
            input.addEventListener('input', () => {
                const p = parseFloat(document.getElementById('panjang').value) || 0;
                const l = parseFloat(document.getElementById('lebar').value) || 0;
                const t = parseFloat(document.getElementById('tinggi').value) || 0;
                document.getElementById('volume').value = (p * l * t).toFixed(2);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\create.blade.php ENDPATH**/ ?>