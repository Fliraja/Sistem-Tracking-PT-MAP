<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            margin: 0;
            padding: 2px 4px;
            /* dikurangi biar rapat */
            line-height: 1.5;
        }

        .header {
            text-align: center;
            font-weight: bold;
            margin-bottom: 2px;
        }

        .subheader {
            text-align: center;
            font-size: 11px;
            margin-bottom: 6px;
        }

        .line {
            border-top: 1px dashed #000;
            margin: 3px 0;
        }

        .info-table {
            width: 100%;
            font-size: 12px;
        }

        .info-table td {
            vertical-align: top;
            padding: 0;
        }

        .label {
            width: 65px;
        }

        .bold {
            font-weight: bold;
        }

        .right {
            text-align: right;
        }

        .footer {
            text-align: center;
            font-size: 10px;
            margin-top: 4px;
        }
    </style>
</head>

<body>

    <div class="header">PT. MANGGALA ASIA PASIFIC</div>
    <div class="subheader">SURAT BONGKAR</div>

    <table class="info-table">
        <tr class="bold">
            <td class="label">No. Struk</td>
            <td>: <?php echo e($attendance->id); ?></td>
        </tr>
        <tr class="bold">
            <td>No. Pol</td>
            <td>: <?php echo e($attendance->mobil->plat ?? '-'); ?></td>
        </tr>
        <tr>
            <td>Tanggal</td>
            <td>: <?php echo e(\Carbon\Carbon::parse($attendance->tanggal_berangkat)->format('d-m-Y H:i')); ?></td>
        </tr>
        <tr>
            <td>Operator</td>
            <td>: <?php echo e($attendance->nama); ?></td>
        </tr>
        <tr>
            <td>Supplier</td>
            <td>: <?php echo e($attendance->supplier ?? '-'); ?></td>
        </tr>
    </table>

    <div class="line"></div>

    <table class="info-table">
        <tr>
            <td class="label">Panjang</td>
            <td>: <?php echo e($attendance->panjang ?? 0); ?> m</td>
        </tr>
        <tr>
            <td>Lebar</td>
            <td>: <?php echo e($attendance->lebar ?? 0); ?> m</td>
        </tr>
        <tr>
            <td>Tinggi</td>
            <td>: <?php echo e($attendance->tinggi ?? 0); ?> m</td>
        </tr>
        <tr>
            <td>Plus</td>
            <td>: <?php echo e($attendance->plus ?? 0); ?> m</td>
        </tr>
        <tr class="bold">
            <td>Volume</td>
            <td>: <?php echo e(number_format($attendance->volume ?? 0, 2)); ?> m³</td>
        </tr>
    </table>

    <div class="line"></div>

    <div class="footer">
        <small>Terima kasih — <?php echo e(now()->format('d/m/Y H:i')); ?></small>
    </div>

</body>

</html>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\print.blade.php ENDPATH**/ ?>