<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-6 mt-6">
        <h1 class="text-2xl font-bold mb-4">Edit Data Attendance</h1>

        <form action="<?php echo e(route('attendances.update', $attendance->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Nomor Plat -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nomor Plat</label>
                <select name="mobil_id" class="w-full border-gray-300 rounded-lg mt-1">
                    <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mobil->id); ?>" <?php echo e($attendance->mobil_id == $mobil->id ? 'selected' : ''); ?>>
                            <?php echo e($mobil->plat); ?> - <?php echo e($mobil->jenis); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Nama Pengemudi -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nama Pengemudi</label>
                <input type="text" id="nama" name="nama" class="w-full border-gray-300 rounded-lg mt-1"
                    value="<?php echo e($attendance->nama); ?>">
            </div>

            <!-- Tanggal dan Jam -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Tanggal & Jam Keberangkatan</label>
                <input type="datetime-local" name="tanggal_berangkat" id="tanggal_berangkat"
                    class="w-full border-gray-300 rounded-lg mt-1"
                    value="<?php echo e(date('Y-m-d\TH:i', strtotime($attendance->tanggal_berangkat))); ?>">
            </div>

            <!-- Supplier -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Supplier</label>
                <input type="text" name="supplier" id="supplier" class="w-full border-gray-300 rounded-lg mt-1"
                    value="<?php echo e($attendance->supplier); ?>">
            </div>

            <!-- Ukuran -->
            <div class="grid grid-cols-3 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 font-medium">Panjang (m)</label>
                    <input type="number" step="0.01" name="panjang" id="panjang"
                        class="w-full border-gray-300 rounded-lg mt-1" value="<?php echo e($attendance->panjang); ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium">Lebar (m)</label>
                    <input type="number" step="0.01" name="lebar" id="lebar"
                        class="w-full border-gray-300 rounded-lg mt-1" value="<?php echo e($attendance->lebar); ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium">Tinggi (m)</label>
                    <input type="number" step="0.01" name="tinggi" id="tinggi"
                        class="w-full border-gray-300 rounded-lg mt-1" value="<?php echo e($attendance->tinggi); ?>">
                </div>
            </div>

            <!-- Volume otomatis -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Volume (m³)</label>
                <input type="number" step="0.01" name="volume" id="volume"
                    class="w-full border-gray-300 rounded-lg mt-1 bg-gray-100" value="<?php echo e($attendance->volume); ?>"
                    readonly>
            </div>

            <!-- Status -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Status</label>
                <select name="status" class="w-full border-gray-300 rounded-lg mt-1">
                    <option value="">-- Pilih Status --</option>
                    <option value="proses" <?php echo e($attendance->status == 'proses' ? 'selected' : ''); ?>>Proses</option>
                    <option value="perjalanan" <?php echo e($attendance->status == 'perjalanan' ? 'selected' : ''); ?>>Perjalanan
                    </option>
                    <option value="selesai" <?php echo e($attendance->status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                </select>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-3">
                <div>
                    <label for="foto_berangkat">Foto Berangkat</label>
                    <input type="file" name="foto_berangkat" id="foto_berangkat" class="form-control">
                    <?php if($attendance->foto_berangkat): ?>
                        <img src="<?php echo e(asset('storage/' . $attendance->foto_berangkat)); ?>" class="mt-2 rounded-lg w-32">
                    <?php endif; ?>
                </div>

                <div>
                    <label for="foto_sampai">Foto Sampai</label>
                    <input type="file" name="foto_sampai" id="foto_sampai" class="form-control">
                    <?php if($attendance->foto_sampai): ?>
                        <img src="<?php echo e(asset('storage/' . $attendance->foto_sampai)); ?>" class="mt-2 rounded-lg w-32">
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tombol Submit -->
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                    Update
                </button>
            </div>
        </form>
    </div>

    <script>
        // Hitung volume otomatis
        document.querySelectorAll('#panjang, #lebar, #tinggi').forEach(input => {
            input.addEventListener('input', () => {
                const p = parseFloat(document.getElementById('panjang').value) || 0;
                const l = parseFloat(document.getElementById('lebar').value) || 0;
                const t = parseFloat(document.getElementById('tinggi').value) || 0;
                document.getElementById('volume').value = (p * l * t).toFixed(2);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\edit.blade.php ENDPATH**/ ?>