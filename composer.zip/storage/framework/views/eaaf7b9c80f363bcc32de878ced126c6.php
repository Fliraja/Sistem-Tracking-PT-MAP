<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: sans-serif;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
        }

        th {
            background: #e5e5e5;
        }

        h1 {
            text-align: center;
            margin-bottom: 3px;
        }

        h2 {
            text-align: center;
            margin-bottom: 0;
        }

        p {
            text-align: center;
            margin-top: 4px;
        }
    </style>
</head>

<body>
    <h1>PT. MANGGALA ASIA PASIFIC</h1>
    <h2><?php echo e($title); ?></h2>
    <p><?php echo e(now()->format('d M Y H:i')); ?></p>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nomor Plat</th>
                <th>Nama Pengemudi</th>
                <th>Supplier</th>
                <th>Tanggal Berangkat</th>
                <th>Status</th>
                <th>Volume (m³)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->mobil->plat ?? '-'); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->supplier ?? '-'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_berangkat)->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e(ucfirst($item->status)); ?></td>
                    <td><?php echo e($item->volume ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Tidak ada data</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\report.blade.php ENDPATH**/ ?>