<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-2xl font-semibold mb-4">Detail Absensi</h1>

        <div class="bg-white rounded-lg shadow p-6">
            <table class="w-full text-sm">
                <tr>
                    <td class="py-2 font-semibold">No. Plat</td>
                    <td class="py-2"><?php echo e($attendance->mobil->plat); ?></td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold w-1/4">Nama</td>
                    <td class="py-2"><?php echo e($attendance->nama); ?></td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Tanggal Berangkat</td>
                    <td class="py-2"><?php echo e(\Carbon\Carbon::parse($attendance->tanggal_berangkat)->format('d-m-Y H:i')); ?>

                    </td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Supplier</td>
                    <td class="py-2"><?php echo e($attendance->supplier); ?></td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Panjang</td>
                    <td class="py-2"><?php echo e($attendance->panjang ?? '0'); ?> m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Lebar</td>
                    <td class="py-2"><?php echo e($attendance->lebar ?? '0'); ?> m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Tinggi</td>
                    <td class="py-2"><?php echo e($attendance->tinggi ?? '0'); ?> m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Plus</td>
                    <td class="py-2"><?php echo e($attendance->plus ?? '0'); ?> m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Volume</td>
                    <td class="py-2"><?php echo e($attendance->volume ?? '0'); ?> m³</td>
                </tr>
                
                <?php if($attendance->foto_berangkat): ?>
                    <div>
                        <strong>Foto Berangkat:</strong><br>
                        <img src="<?php echo e(asset('storage/' . $attendance->foto_berangkat)); ?>" alt="Foto Berangkat"
                            class="mt-2 rounded-lg shadow-md max-w-full h-auto">
                    </div>
                <?php endif; ?>

                
                <?php if($attendance->foto_sampai): ?>
                    <div>
                        <strong>Foto Sampai:</strong><br>
                        <img src="<?php echo e(asset('storage/' . $attendance->foto_sampai)); ?>" alt="Foto Sampai"
                            class="mt-2 rounded-lg shadow-md max-w-full h-auto">
                    </div>
                <?php endif; ?>

                <tr>
                    <td class="py-2 font-semibold">Status</td>
                    <td class="py-2">
                        <span
                            class="px-2 py-1 rounded text-white 
                        <?php if($attendance->status == 'proses'): ?> bg-yellow-500 
                        <?php elseif($attendance->status == 'perjalanan'): ?> bg-blue-500 
                        <?php else: ?> bg-green-600 <?php endif; ?>">
                            <?php echo e(ucfirst($attendance->status)); ?>

                        </span>
                    </td>
                </tr>
            </table>
        </div>

        <div class="mt-6">
            <a href="<?php echo e(route('attendances.index')); ?>"
                class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md">
                Kembali
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\show.blade.php ENDPATH**/ ?>