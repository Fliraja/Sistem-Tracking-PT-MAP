<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-6xl mx-auto bg-white shadow-md rounded-lg p-6 mt-6">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-2xl font-semibold">Daftar Absensi Mobil</h2>
            <a href="<?php echo e(route('attendances.create')); ?>"
                class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                + Tambah Absensi
            </a>
            <a href="<?php echo e(route('attendances.export.pdf', request()->all())); ?>"
                class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Export PDF
            </a>
        </div>

        
        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="mb-6 relative">
            
            

            
            <form id="filterForm" action="<?php echo e(route('attendances.index')); ?>" method="GET"
                class="flex flex-wrap gap-4 items-end">
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1">Filter Berdasarkan</label>
                    <select id="filter_type" name="filter_type" class="border-gray-300 rounded-lg">
                        <option value="">-- Pilih Filter --</option>
                        <option value="harian" <?php echo e(request('filter_type') == 'harian' ? 'selected' : ''); ?>>Harian</option>
                        <option value="bulanan" <?php echo e(request('filter_type') == 'bulanan' ? 'selected' : ''); ?>>Bulanan
                        </option>
                        <option value="mobil" <?php echo e(request('filter_type') == 'mobil' ? 'selected' : ''); ?>>Mobil</option>
                        <option value="supplier" <?php echo e(request('filter_type') == 'supplier' ? 'selected' : ''); ?>>Supplier
                        </option>
                    </select>
                </div>

                
                <div id="filter_fields" class="flex gap-4 items-end"></div>

                
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Terapkan
                </button>
            </form>
        </div>

        
        <div class="overflow-x-auto">
            <?php echo $__env->make('attendances.partials.table', ['attendances' => $attendances], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const filterType = document.getElementById('filter_type');
            const filterFields = document.getElementById('filter_fields');

            // data untuk populasi mobil dari server
            const mobils = <?php echo json_encode($mobils, 15, 512) ?>;

            function renderFilterFields() {
                const type = filterType.value;
                filterFields.innerHTML = ''; // kosongkan dulu

                if (type === 'harian') {
                    filterFields.innerHTML = `
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">Tanggal</label>
                            <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="border-gray-300 rounded-lg">
                        </div>
                    `;
                } else if (type === 'bulanan') {
                    filterFields.innerHTML = `
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">Bulan</label>
                            <input type="month" name="month" value="<?php echo e(request('month')); ?>" class="border-gray-300 rounded-lg">
                        </div>
                    `;
                } else if (type === 'mobil') {
                    let options = mobils.map(m =>
                        `<option value="${m.id}" <?php echo e(request('mobil_id') == '${m.id}' ? 'selected' : ''); ?>>${m.plat} - ${m.jenis}</option>`
                    ).join('');

                    filterFields.innerHTML = `
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">Mobil</label>
                            <select name="mobil_id" class="border-gray-300 rounded-lg">${options}</select>
                        </div>
                    `;
                } else if (type === 'supplier') {
                    filterFields.innerHTML = `
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">Supplier</label>
                            <input type="text" name="supplier" value="<?php echo e(request('supplier')); ?>" class="border-gray-300 rounded-lg">
                        </div>
                    `;
                }
            }

            // render form saat pertama kali (misal dari reload)
            renderFilterFields();

            // render ulang jika dropdown berubah
            filterType.addEventListener('change', renderFilterFields);
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\absensimobilirvan\resources\views\attendances\index.blade.php ENDPATH**/ ?>