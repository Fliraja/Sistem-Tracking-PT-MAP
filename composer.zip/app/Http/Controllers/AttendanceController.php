<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Mobil;
use App\Models\Attendance;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        $query = Attendance::with('mobil');

        switch ($request->filter_type) {
            case 'harian':
                if ($request->date) {
                    $query->whereDate('tanggal_berangkat', $request->date);
                }
                break;

            case 'bulanan':
                if ($request->month) {
                    $month = \Carbon\Carbon::parse($request->month);
                    $query->whereMonth('tanggal_berangkat', $month->month)
                        ->whereYear('tanggal_berangkat', $month->year);
                }
                break;

            case 'mobil':
                if ($request->mobil_id) {
                    $query->where('mobil_id', $request->mobil_id);
                }
                break;

            case 'supplier':
                if ($request->supplier) {
                    $query->where('supplier', 'like', '%' . $request->supplier . '%');
                }
                break;
        }

        $attendances = $query->latest('tanggal_berangkat')->paginate(100);
        $mobils = Mobil::all();

        return view('attendances.index', compact('attendances', 'mobils'));
    }


    public function show($id)
    {
        $attendance = Attendance::with('mobil')->findOrFail($id);
        return view('attendances.show', compact('attendance'));
    }

    public function print($id)
    {
        $attendance = Attendance::with('mobil')->findOrFail($id);

        $pdf = Pdf::loadView('attendances.print', compact('attendance'))
            ->setPaper([0, 0, 226.77, 600], 'portrait');
        // 226.77pt ≈ 8 cm lebar (thermal)

        return $pdf->stream('surat_jalan_' . $attendance->id . '.pdf');
    }

    public function create()
    {
        $mobils = Mobil::all();
        return view('attendances.create', compact('mobils'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'mobil_id' => 'required|exists:mobils,id',
            'nama' => 'required|string|max:100',
            'tanggal_berangkat' => 'required|date',
            'supplier' => 'required|string',
            'panjang' => 'nullable|numeric',
            'lebar' => 'nullable|numeric',
            'tinggi' => 'nullable|numeric',
            'plus' => 'nullable|numeric',
            'volume' => 'nullable|numeric',
            'foto_berangkat' => 'nullable|image|max:2048',
            'foto_sampai' => 'nullable|image|max:2048',
            'status' => 'in:proses,perjalanan,selesai',
        ]);

        // dd($validated); // 🧠 tambahkan ini dulu

        if ($request->hasFile('foto_berangkat')) {
            $validated['foto_berangkat'] = $request->file('foto_berangkat')->store('uploads/foto_berangkat', 'public');
        }
        if ($request->hasFile('foto_sampai')) {
            $validated['foto_sampai'] = $request->file('foto_sampai')->store('uploads/foto_sampai', 'public');
        }

        Attendance::create($validated);

        return redirect()->route('attendances.index')->with('success', 'Data absensi berhasil disimpan!');
    }

    public function edit(Attendance $attendance)
    {
        $mobils = Mobil::all();
        return view('attendances.edit', compact('attendance', 'mobils'));
    }

    public function update(Request $request, Attendance $attendance)
    {
        $validated = $request->validate([
            'mobil_id' => 'required|exists:mobils,id',
            'nama' => 'required|string|max:100',
            'tanggal_berangkat' => 'required|date',
            'supplier' => 'required|string',
            'panjang' => 'nullable|numeric',
            'lebar' => 'nullable|numeric',
            'tinggi' => 'nullable|numeric',
            'plus' => 'nullable|numeric',
            'volume' => 'nullable|numeric',
            'status' => 'required|in:proses,perjalanan,selesai',
            'foto_berangkat' => 'nullable|image|max:2048',
            'foto_sampai' => 'nullable|image|max:2048',
        ]);

        // 🖼️ Update foto kalau ada yang baru
        if ($request->hasFile('foto_berangkat')) {
            $path = $request->file('foto_berangkat')->store('uploads/foto_berangkat', 'public');
            $validated['foto_berangkat'] = $path;
        }

        if ($request->hasFile('foto_sampai')) {
            $path = $request->file('foto_sampai')->store('uploads/foto_sampai', 'public');
            $validated['foto_sampai'] = $path;
        }

        $attendance->update($validated);

        return redirect()->route('attendances.index')->with('success', 'Data attendance berhasil diperbarui!');
    }

    public function destroy(Attendance $attendance)
    {
        // // Hapus foto dari storage jika ada
        // if ($attendance->foto_berangkat) {
        //     \Storage::disk('public')->delete($attendance->foto_berangkat);
        // }
        // if ($attendance->foto_sampai) {
        //     \Storage::disk('public')->delete($attendance->foto_sampai);
        // }

        $attendance->delete();

        return redirect()->route('attendances.index')->with('success', 'Data attendance berhasil dihapus!');
    }

    public function exportPdf(Request $request)
    {
        $query = Attendance::with('mobil');

        switch ($request->filter_type) {
            case 'harian':
                if ($request->date) {
                    $query->whereDate('tanggal_berangkat', $request->date);
                }
                break;

            case 'bulanan':
                if ($request->month) {
                    $month = Carbon::parse($request->month);
                    $query->whereMonth('tanggal_berangkat', $month->month)
                        ->whereYear('tanggal_berangkat', $month->year);
                }
                break;

            case 'mobil':
                if ($request->mobil_id) {
                    $query->where('mobil_id', $request->mobil_id);
                }
                break;

            case 'supplier':
                if ($request->supplier) {
                    $query->where('supplier', 'like', '%' . $request->supplier . '%');
                }
                break;
        }

        $attendances = $query->latest('tanggal_berangkat')->get();

        // Judul laporan dinamis
        $title = 'Laporan Data Absensi';
        if ($request->filter_type) {
            $title .= ' (' . ucfirst($request->filter_type) . ')';
        }

        $pdf = Pdf::loadView('attendances.report', compact('attendances', 'title'))
            ->setPaper('A4', 'portrait');

        return $pdf->stream('laporan_absensi.pdf');
    }

}
