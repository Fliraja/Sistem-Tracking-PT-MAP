<x-app-layout>
    {{-- <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Home Admin') }}
        </h2>
    </x-slot> --}}

    <div class="py-4">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="mx-4 bg-white dark:bg-gray-800 overflow-hidden shadow-sm rounded-full">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    Hai, {{ Auth::user()->name }}!
                </div>
            </div>
            <hr class="w-auto h-px mx-auto mt-4 bg-gray-200 dark:bg-gray-500 border-0 rounded md:my-10">
            <div class="p-4">

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div class="max-w-sm p-6 bg-blue-800 border border-blue-700 hover:bg-blue-900 rounded-lg shadow-sm">
                        <a href="#">
                            <?xml version="1.0" encoding="utf-8"?><!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
                            <svg class="w-7 h-7 text-gray-500 dark:text-gray-400 mb-3" viewBox="0 0 24 24"
                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M17.5 6.75H15.5V6C15.5 5.04 14.71 4.25 13.75 4.25H4.5C3.54 4.25 2.75 5.04 2.75 6V15C2.75 15.96 3.54 16.75 4.5 16.75H4.78C4.91 18.42 6.3 19.75 8 19.75C9.7 19.75 11.09 18.42 11.22 16.75H12.77C12.9 18.42 14.29 19.75 15.99 19.75C17.69 19.75 19.08 18.42 19.21 16.75H19.49C20.45 16.75 21.24 15.96 21.24 15V10.5C21.24 8.43 19.56 6.75 17.49 6.75H17.5ZM4.25 15V6C4.25 5.86 4.36 5.75 4.5 5.75H13.75C13.89 5.75 14 5.86 14 6V13.94C14 13.94 13.95 14 13.92 14.02C13.77 14.15 13.63 14.29 13.5 14.44C13.46 14.49 13.42 14.53 13.39 14.58C13.24 14.79 13.1 15 13.01 15.24H11.01C11.01 15.24 11.01 15.24 11.01 15.23C10.94 15.06 10.84 14.89 10.74 14.74C10.71 14.7 10.68 14.66 10.65 14.61C10.57 14.49 10.48 14.39 10.38 14.28C10.34 14.24 10.31 14.2 10.27 14.16C10.14 14.04 10.01 13.93 9.87 13.83C9.85 13.82 9.84 13.8 9.82 13.79C9.67 13.69 9.51 13.61 9.35 13.53C9.29 13.5 9.23 13.48 9.17 13.46C9.04 13.41 8.92 13.37 8.79 13.34C8.73 13.33 8.67 13.31 8.61 13.3C8.42 13.26 8.22 13.24 8.02 13.24C7.82 13.24 7.63 13.26 7.43 13.3C7.37 13.31 7.31 13.33 7.25 13.34C7.12 13.37 6.99 13.41 6.87 13.46C6.81 13.48 6.75 13.5 6.69 13.53C6.53 13.6 6.37 13.69 6.22 13.79C6.2 13.8 6.19 13.81 6.17 13.83C6.03 13.93 5.89 14.04 5.77 14.16C5.73 14.2 5.69 14.24 5.66 14.28C5.56 14.38 5.47 14.49 5.39 14.61C5.36 14.65 5.33 14.69 5.3 14.74C5.2 14.9 5.11 15.06 5.03 15.23C5.03 15.23 5.03 15.23 5.03 15.24H4.53C4.39 15.24 4.28 15.13 4.28 14.99L4.25 15ZM8 18.25C7.04 18.25 6.25 17.46 6.25 16.5C6.25 16.38 6.26 16.26 6.29 16.15C6.33 15.97 6.4 15.8 6.49 15.65C6.5 15.62 6.52 15.6 6.53 15.57C6.62 15.43 6.73 15.3 6.86 15.19C6.89 15.17 6.91 15.15 6.94 15.13C7.07 15.03 7.22 14.94 7.38 14.88C7.4 14.88 7.43 14.86 7.46 14.86C7.63 14.8 7.82 14.76 8.01 14.76C8.2 14.76 8.38 14.8 8.56 14.86C8.59 14.86 8.61 14.87 8.64 14.88C8.8 14.94 8.95 15.03 9.08 15.13C9.11 15.15 9.13 15.17 9.16 15.19C9.29 15.3 9.4 15.43 9.49 15.57C9.51 15.59 9.52 15.62 9.53 15.65C9.62 15.81 9.69 15.97 9.73 16.15C9.75 16.26 9.77 16.38 9.77 16.5C9.77 17.46 8.98 18.25 8.02 18.25H8ZM16 18.25C15.04 18.25 14.25 17.46 14.25 16.5C14.25 16.38 14.26 16.26 14.29 16.15C14.32 16.03 14.35 15.91 14.4 15.8C14.4 15.8 14.4 15.79 14.4 15.78C14.45 15.68 14.5 15.58 14.57 15.49C14.58 15.47 14.6 15.46 14.61 15.44C14.67 15.36 14.73 15.29 14.8 15.22C14.82 15.2 14.84 15.19 14.86 15.17C14.93 15.11 15.01 15.05 15.09 15C15.11 14.99 15.14 14.97 15.17 14.96C15.26 14.91 15.36 14.87 15.46 14.84C15.5 14.83 15.54 14.81 15.59 14.8C15.72 14.77 15.86 14.75 16 14.75C16.19 14.75 16.37 14.79 16.55 14.85C16.58 14.85 16.6 14.86 16.63 14.87C16.79 14.93 16.94 15.02 17.07 15.12C17.1 15.14 17.12 15.16 17.15 15.18C17.28 15.29 17.39 15.42 17.48 15.56C17.5 15.58 17.51 15.61 17.52 15.64C17.61 15.8 17.68 15.96 17.72 16.14C17.74 16.25 17.76 16.37 17.76 16.49C17.76 17.45 16.97 18.24 16.01 18.24L16 18.25ZM15.5 11.25V8.25H17.5C18.74 8.25 19.75 9.26 19.75 10.5V11.25H15.5Z" />
                            </svg>

                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                {{ $totalMobil }}</h5>

                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">Mobil
                            </h5>
                        </a>
                    </div>
                    <div
                        class="max-w-sm p-6 bg-green-800 border border-green-700 hover:bg-green-900 rounded-lg shadow-sm ">
                        <a href="#">
                            <svg class="w-7 h-7 text-gray-500 dark:text-gray-400 mb-3" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                viewBox="0 0 24 24">
                                <path fill-rule="evenodd"
                                    d="M4 5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H4Zm0 6h16v6H4v-6Z"
                                    clip-rule="evenodd" />
                                <path fill-rule="evenodd"
                                    d="M5 14a1 1 0 0 1 1-1h2a1 1 0 1 1 0 2H6a1 1 0 0 1-1-1Zm5 0a1 1 0 0 1 1-1h5a1 1 0 1 1 0 2h-5a1 1 0 0 1-1-1Z"
                                    clip-rule="evenodd" />
                            </svg>


                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                {{ $absensiHariIni }}</h5>

                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">Absensi
                                Hari ini
                            </h5>
                        </a>
                    </div>
                    <div class="max-w-sm p-6 bg-red-800 border border-red-700 hover:bg-red-900 rounded-lg shadow-sm ">
                        <a href="#">
                            <svg class="w-7 h-7 text-gray-500 dark:text-gray-400 mb-3" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M15 9h.01M8.99 9H9m12 3a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM6.6 13a5.5 5.5 0 0 0 10.81 0H6.6Z" />
                            </svg>


                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                {{ $totalSupplier }}</h5>

                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                Supplier
                            </h5>
                        </a>
                    </div>
                    <div
                        class="max-w-sm p-6 bg-yellow-600 border border-yellow-500 hover:bg-yellow-700 rounded-lg shadow-sm ">
                        <a href="#">
                            <svg class="w-7 h-7 text-gray-500 dark:text-gray-400 mb-3" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M21 8v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8m18 0-8.029-4.46a2 2 0 0 0-1.942 0L3 8m18 0-9 6.5L3 8" />
                            </svg>


                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                {{ $suratBulanIni }}</h5>

                            <h5 class="mb-2 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">Surat
                                Bulan ini
                            </h5>
                        </a>
                    </div>
                </div>

                {{-- 🔹 Grafik Aktivitas Bulanan --}}
                <div class="bg-white shadow rounded-2xl p-6 mb-8">
                    <h3 class="text-xl font-semibold text-gray-700 mb-4">
                        Aktivitas Absensi Bulan {{ now()->translatedFormat('F Y') }}
                    </h3>
                    <canvas id="attendanceChart" height="100"></canvas>
                </div>


                <div class=" mt-4 relative overflow-x-auto shadow-md sm:rounded-lg">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xl font-semibold text-gray-700 dark:text-white">Absensi Terbaru</h3>
                        <a href="{{ route('attendances.index') }}" class="text-blue-600 hover:underline">Lihat Semua</a>
                    </div>
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    Tanggal
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Mobil
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Supplier
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Status
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($recentAttendances ?? [] as $attendance)
                                <tr>
                                    <td class="px-4 py-2 text-sm text-gray-700 dark:text-white">
                                        {{ \Carbon\Carbon::parse($attendance->tanggal_berangkat)->format('d/m/Y') }}
                                    </td>
                                    <td class="px-4 py-2 text-sm text-gray-700 dark:text-white">
                                        {{ $attendance->mobil->plat ?? '-' }}
                                    </td>
                                    <td class="px-4 py-2 text-sm text-gray-700 dark:text-white">
                                        {{ $attendance->supplier ?? '-' }}
                                    </td>
                                    <td class="px-4 py-2 text-sm">
                                        <span
                                            class="px-2 py-1 rounded-full text-xs
                                        {{ $attendance->status === 'proses'
                                            ? 'bg-yellow-100 text-yellow-700'
                                            : ($attendance->status === 'perjalanan'
                                                ? 'bg-blue-100 text-blue-700'
                                                : 'bg-green-100 text-green-700') }}">
                                            {{ ucfirst($attendance->status) }}
                                        </span>
                                    </td>
                                    <td class="px-4 py-2 text-sm">
                                        <a href="{{ route('attendances.print', $attendance->id) }}"
                                            class="text-blue-600 hover:underline">Cetak</a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" class="px-4 py-3 text-center text-gray-500">Belum ada data</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
    {{-- 🔹 Chart.js Script --}}
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('attendanceChart');
        const attendanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: @json($labels),
                datasets: [{
                    label: 'Jumlah Absensi per Hari',
                    data: @json($data),
                    backgroundColor: 'rgba(37, 99, 235, 0.6)',
                    borderColor: 'rgba(37, 99, 235, 1)',
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        title: {
                            display: true,
                            text: 'Jumlah',
                            font: {
                                size: 14,
                                weight: 'bold'
                            }
                        },
                        beginAtZero: true
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Tanggal',
                            font: {
                                size: 14,
                                weight: 'bold'
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: true
                    }
                }
            }
        });
    </script>
</x-app-layout>
