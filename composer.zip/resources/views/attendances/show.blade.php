<x-app-layout>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-2xl font-semibold mb-4">Detail Absensi</h1>

        <div class="bg-white rounded-lg shadow p-6">
            <table class="w-full text-sm">
                <tr>
                    <td class="py-2 font-semibold">No. Plat</td>
                    <td class="py-2">{{ $attendance->mobil->plat }}</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold w-1/4">Nama</td>
                    <td class="py-2">{{ $attendance->nama }}</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Tanggal Berangkat</td>
                    <td class="py-2">{{ \Carbon\Carbon::parse($attendance->tanggal_berangkat)->format('d-m-Y H:i') }}
                    </td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Supplier</td>
                    <td class="py-2">{{ $attendance->supplier }}</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Panjang</td>
                    <td class="py-2">{{ $attendance->panjang ?? '0' }} m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Lebar</td>
                    <td class="py-2">{{ $attendance->lebar ?? '0' }} m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Tinggi</td>
                    <td class="py-2">{{ $attendance->tinggi ?? '0' }} m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Plus</td>
                    <td class="py-2">{{ $attendance->plus ?? '0' }} m</td>
                </tr>
                <tr>
                    <td class="py-2 font-semibold">Volume</td>
                    <td class="py-2">{{ $attendance->volume ?? '0' }} m³</td>
                </tr>
                {{-- FOTO BERANGKAT --}}
                @if ($attendance->foto_berangkat)
                    <div>
                        <strong>Foto Berangkat:</strong><br>
                        <img src="{{ asset('storage/' . $attendance->foto_berangkat) }}" alt="Foto Berangkat"
                            class="mt-2 rounded-lg shadow-md max-w-full h-auto">
                    </div>
                @endif

                {{-- FOTO SAMPAI --}}
                @if ($attendance->foto_sampai)
                    <div>
                        <strong>Foto Sampai:</strong><br>
                        <img src="{{ asset('storage/' . $attendance->foto_sampai) }}" alt="Foto Sampai"
                            class="mt-2 rounded-lg shadow-md max-w-full h-auto">
                    </div>
                @endif

                <tr>
                    <td class="py-2 font-semibold">Status</td>
                    <td class="py-2">
                        <span
                            class="px-2 py-1 rounded text-white 
                        @if ($attendance->status == 'proses') bg-yellow-500 
                        @elseif($attendance->status == 'perjalanan') bg-blue-500 
                        @else bg-green-600 @endif">
                            {{ ucfirst($attendance->status) }}
                        </span>
                    </td>
                </tr>
            </table>
        </div>

        <div class="mt-6">
            <a href="{{ route('attendances.index') }}"
                class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md">
                Kembali
            </a>
        </div>
    </div>
</x-app-layout>
